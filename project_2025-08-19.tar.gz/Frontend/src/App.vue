<template>
  <!-- The top-level component simply renders the current route's component. -->
  <router-view />
</template>

<script setup>
// There is no additional logic in the root component.
</script>

<style>
/* Global styles can be placed here if needed. */
</style>